this.cfgInfo = {
  development: {
    baseURL: '//localhost/cable_monitor/backend/api/index.php/',
  },
  production: {
    baseURL: './api/index.php/',
  }
}
this.cfgInfo = {
  development: {
    baseURL: 'http://172.17.11.93/api/index.php/',
  },
  production: {
    baseURL: '../api/index.php/',
  }
}

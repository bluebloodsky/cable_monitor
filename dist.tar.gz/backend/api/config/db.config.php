<?php
return [
    // required
	'database_type' => 'mysql',
	'database_name' => 'libgcc',
	'server' => '172.17.11.93',
	'username' => 'libgcc',
	'password' => 'libgcc',
	'charset' => 'utf8'
];